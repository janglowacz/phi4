import sys
import numpy as np
import matplotlib.pyplot as plt
import time
import scipy.optimize as so

import Theory_Alt as Theory
import Utility

Tracker = Utility.Tracker()

Lattice = Theory.Lattice()
Lattice.load("Corr/Corr")

t_s = np.linspace(0, Lattice.Size[0]//2, Lattice.Shape[0]//2+1)
TPC = np.zeros([t_s.size, len(Lattice.History)])

runs = len(Lattice.History)*len(t_s)
Tracker.START()
for i in range(len(Lattice.History)):
    for t in range(len(t_s)):
        Tracker.FLUSH(t+(i*len(t_s)), runs)
        TPC[t, i] = Lattice.two_Point_Average(t, phi = Lattice.History[i])
Tracker.FLUSH_Final(runs, runs)

TP = TPC.mean(axis = 1)
TP = TP / TPC.mean(axis = 1)[0]
TPE = np.array([Utility.bootstrap(TPC[t,:], 10000) for t in range(len(t_s))])
TPE = np.sqrt(np.square(TPE[0] * TP / np.square(TPC.mean(axis = 1)[0])) + np.square(TPE / TPC.mean(axis = 1)[0]))
TPE[0] = 0

def func(x,a):
    return np.exp(-a * x)

par, cov = so.curve_fit(func, t_s[1:], TP[1:], [1], sigma = TPE[1:], absolute_sigma=True)

X = np.sum(np.square((TP[1:] - func(t_s[1:],*par))/TPE[1:]))
print()
print(par)
print(np.sqrt(cov.diagonal()))
print(X, t_s.size - len(par), X / (t_s.size - len(par)))

lin = np.linspace(0,Lattice.Size[0]//2,1000)

plt.figure(figsize=(6,4))
# plt.yscale("log")
plt.errorbar(t_s, TP, yerr = TPE, fmt = "x", label="values", capsize=3)
# plt.plot(lin, [func(x, *par) for x in lin], label="fit")
# plt.plot(lin, [func(x, 1) for x in lin], "--", label="start params")
plt.legend(loc="best")
plt.grid()
plt.xlabel(r"$t$")
plt.ylabel(r"$C_2(t)/C_2(0)$")
plt.savefig("Lat_Corr.pdf")
plt.show()
plt.close()