import sys
import numpy as np
import matplotlib.pyplot as plt
import time
import scipy.optimize as so
import scipy.special as sx

import Theory_Alt as Theory
import Utility

Tracker = Utility.Tracker()

Kappa_s = np.linspace(1,10,10)

lin = np.linspace(Kappa_s.min(), Kappa_s.max(), 1000)

Alpha_s = [1,3,5]

MEFF_S = []
MEFF_E_S = []

Par_s = []
Cov_s = []

def startpars(L):
    return [0.15*L+0.05, -0.02*L+1.45, -0.05*L+0.6, 0.1]

def fitfunc(x, a, b, c, d):
    RET = np.zeros(len(np.array(x)))
    RET[x<c] = a * np.exp( b * x[x<c] )
    RET[x>=c] = a * np.exp( b * c ) + ( x[x>=c] - c ) * d
    return RET

for Alpha in Alpha_s:
    Lattice_s = []
    TP_s, TPE_s = [], []

    Meff_s, Meff_E_s = [], []

    for Kappa in Kappa_s:
        Lattice_s.append(Theory.Lattice())
        Lattice_s[-1].load("Meff_B/Kappa_"+str(Kappa)+"_Alpha_"+str(Alpha))

        TP, TPE = Lattice_s[-1].two_Point_Corr_Full(Tracker = Tracker, Full = False)

        Meff_s.append(-np.log(TP[1]))
        Meff_E_s.append(TPE[1]/TP[1])

    MEFF_S.append(Meff_s)
    MEFF_E_S.append(Meff_E_s)

    #Spars = startpars(Alpha)
    #par, cov = so.curve_fit(fitfunc, M_squared_s, Meff_s, Spars, sigma = Meff_E_s, absolute_sigma=True)
    #Par_s.append(par)
    #Cov_s.append(cov)

plt.figure(figsize=(9,6))

i = -1
for Alpha in Alpha_s:
    i+=1
    plt.errorbar(Kappa_s, MEFF_S[i], yerr = MEFF_E_S[i], fmt = "x", label = r"$\alpha = $"+str(Alpha), capsize = 3, color = "C"+str(i))
    #plt.plot(lin, fitfunc(lin, *Par_s[i]), color = "C"+str(i), alpha = 0.5)
    #Spars = startpars(Lambda)
    #plt.plot(lin, fitfunc(lin,*Spars),"--", color = "C"+str(i), alpha = 0.5)
    #X = np.sum(np.square((MEFF_S[i] - fitfunc(M_squared_s, *Par_s[i]))/MEFF_E_S[i]))
    #print()
    #print(Lambda)
    #print(startpars(Lambda))
    #print(Par_s[i])
    #print(np.sqrt(Cov_s[i].diagonal()))
    #print(X, M_squared_s.size - 4, X / (M_squared_s.size - 4))
plt.legend(loc = "best")
plt.grid()
plt.xlabel(r"$\mu^2$")
plt.ylabel(r"$m_\mathrm{eff}$")
plt.savefig("Lat_Meff_B.pdf")
plt.show()
plt.close()