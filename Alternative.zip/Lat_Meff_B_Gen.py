import sys
import numpy as np
import matplotlib.pyplot as plt
import time

import Theory_Alt as Theory
import Utility

Kappa_s = np.linspace(1,10,10)

# ================================================
# CHANGE THIS TO RUN DIFFERENT SETTINGS
#       |
#       V
Alpha = 5

for Kappa in Kappa_s:
    print()
    print("Alpha:", Alpha)
    Lattice = Theory.Lattice(Parameters = [Kappa, Alpha], Size = [10,10,10,10], Spacing = [1,1,1,1])
    Lattice.History = []
    Lattice.Phi = np.ones(Lattice.Shape)*0.1

    Tracker = Utility.Tracker()

    Thermalization = 25
    Sweeps = 50

    Steps = 4

    print("Size:",Lattice.Size)
    print("Spacing:",Lattice.Spacing)
    print("Shape:",Lattice.Shape)


    print("Thermalization:")
    Tracker.START()
    for k in range(Thermalization):
        Tracker.FLUSH(k, Thermalization)
        Lattice.Sweep(Steps = Steps)
    Tracker.FLUSH_Final(Thermalization, Thermalization)
    print()

    print("Sweeps:")
    Tracker.START()
    for k in range(Sweeps):
        Tracker.FLUSH(k, Sweeps)
        Lattice.Sweep(Steps = Steps, Save = True)
    Tracker.FLUSH_Final(Sweeps, Sweeps)
    print()

    print("Acceptance:",Lattice.Accepted/Lattice.Tried)

    Lattice.save("Meff_B/Kappa_"+str(Kappa)+"_Alpha_"+str(Alpha))