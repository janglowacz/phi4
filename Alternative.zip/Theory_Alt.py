import sys
import numpy as np
import matplotlib.pyplot as plt
import json

import Utility

class Lattice:
    Accepted = 0
    Tried = 0
    History = []
    PhysicalHistory = []



    # ========================================================
    # CONSTRUCTOR + LOADING & MANIPULATION METHODS
    # ========================================================

    # Constructor of the lattice
    def __init__(self, *args, **kwargs):
        if len(args) == 0 and len(kwargs) == 0:
            print("Lattice initialized without parameters")
        else:
            if "Shape" in kwargs and "Size" in kwargs:
                self.Shape = np.array(kwargs["Shape"])
                self.Size = np.array(kwargs["Size"])
                self.Spacing = np.array(self.Size / self.Shape)
            elif "Shape" in kwargs and "Spacing" in kwargs:
                self.Shape = np.array(kwargs["Shape"])
                self.Spacing = np.array(kwargs["Spacing"])
                self.Size = np.array(self.Size * self.Spacing)
            elif "Spacing" in kwargs and "Size" in kwargs:
                self.Size = np.array(kwargs["Size"])
                self.Spacing = np.array(kwargs["Spacing"])
                self.Shape = np.array(self.Size / self.Spacing).astype(int)
            else: raise Exception("Error in determining lattice dimensions")
            self.Phi = np.zeros(self.Shape)
            self.Kappa, self.Alpha = kwargs["Parameters"]
            self.Dmax = np.sqrt(self.Spacing[0]*0.08)
            self.PhysicalPhi = np.zeros(self.Shape)
            self.Mu_squared = 0
            self.Lambda = 0
            print("Lattice initialized with parameters")

    # Method to save the lattice into a file
    def save(self, filename):
        DATA = {"Accepted":     self.Accepted,
                "Tried":        self.Tried,
                "History":      [phi.tolist() for phi in self.History],
                "Shape":        self.Shape.tolist(),
                "Size":         self.Size.tolist(),
                "Spacing":      self.Spacing.tolist(),
                "Phi":          self.Phi.tolist(),
                "Kappa":        self.Kappa,
                "Alpha":        self.Alpha,
                "Dmax":         self.Dmax}
        with open(filename + ".json", mode = "w") as f:
            f.write(json.dumps(DATA))
        print("Lattice saved to file \'"+filename+".json\'")

    # Method to load the lattice from a file
    def load(self, filename):
        with open(filename + ".json", mode = "r") as f:
            DATA = json.loads(f.read())
        self.Accepted   = DATA["Accepted"]
        self.Tried      = DATA["Tried"]
        self.History    = [np.array(phi) for phi in DATA["History"]]
        self.Shape      = np.array(DATA["Shape"])
        self.Size       = np.array(DATA["Size"])
        self.Spacing    = np.array(DATA["Spacing"])
        self.Spacing    = np.array(DATA["Spacing"])
        self.Phi        = np.array(DATA["Phi"])
        self.Kappa      = DATA["Kappa"]
        self.Alpha      = DATA["Alpha"]
        self.Dmax       = DATA["Dmax"]  
        print("Lattice initialized from file \'"+filename+".json\'")

    # Method to set the parameters Kappa and Alpha from the parameters Mu^2 and Lambda
    def set_Parameters(self, m, l):
        if not self.Shape.size == 4: raise Exception("You are trying to run code that only works in 4dim on a " + str(self.Shape.size)+"dim Lattice")
        self.Mu_squared = m
        self.Lambda = l
        a = self.Spacing[0]     
        self.Alpha = self.Lambda / (6*np.square(a)*self.Mu_squared + 48 + 2*self.Lambda)
        self.Kappa = 6 * self.Alpha / self.Lambda

    # Method to convert the Field \varphi to \phi
    def Convert_Phi(self, phi = None):
        if not type(phi) == np.ndarray: phi = self.Phi
        self.PhysicalPhi = phi * self.Spacing[0] / (2*np.sqrt(self.Kappa))
        self.Lambda = 6 * self.Alpha / self.Kappa
        self.Mu_squared = ( (1-2*self.Alpha)/self.Kappa - 8 ) / np.square(self.Spacing[0])

    # Method to convert the History \varphi to \phi
    def Convert_History(self):
        self.PhysicalHistory = []
        for phi in self.History:
            self.PhysicalHistory.append(phi * self.Spacing[0] / (2*np.sqrt(self.Kappa)))
        self.Lambda = 6 * self.Alpha / self.Kappa
        self.Mu_squared = ( (1-2*self.Alpha)/self.Kappa - 8 ) / np.square(self.Spacing[0])  



    # ========================================================
    # MONTE CARLO METHODS
    # ========================================================
        
    # Method to perform 1 sweep over the lattice
    def Sweep(self, J=0, Steps=1, Save=False, sampling="uniform"):
        for x, _ in np.ndenumerate(self.Phi): # Sweep over all lattice sites
            for _ in range(Steps): # Steps times

                # Execute the Delta_Phi sampling
                if sampling == "uniform": Delta_Phi = np.random.uniform(-self.Dmax, self.Dmax)
                elif sampling == "gauss": Delta_Phi = np.random.randn() * self.Dmax
                else: raise Exception("\'" + str(sampling) + "\' is not a valid sampling type")

                # Determine the change in the action
                Delta_S = self.Delta_S(x, Delta_Phi, J=J)

                # Perform the Metropolis-Hastings accept-reject step
                if Delta_S < 0 or np.random.uniform(0,1) <= np.exp(-Delta_S):
                    self.Phi[x] += Delta_Phi
                    self.Accepted += 1
                self.Tried += 1
        if Save: self.History.append(self.Phi.copy())

    # Method to calculate the change in action
    def Delta_S(self, x, Delta_Phi, J=0):
        new_phi = self.Phi[x] + Delta_Phi
        Term_Nothing = (np.square(new_phi) - np.square(self.Phi[x]))
        Term_Alpha = self.Alpha * (np.square(np.square(new_phi)-1) - np.square(np.square(self.Phi[x])-1))
        Term_J = J * np.sqrt(2*self.Kappa)*self.Alpha * (new_phi - self.Phi[x])
        Term_Kin = 0
        for i in range(4):
            shift = np.zeros(4)
            shift[i] = 1
            Term_Kin += (new_phi - self.Phi[x]) * (self.Phi[tuple(((x + shift)%self.Shape).astype(int))] + self.Phi[tuple(((x - shift)%self.Shape).astype(int))])
        return (Term_Nothing + Term_Alpha - 2*self.Kappa * Term_Kin - Term_J)



    # ========================================================
    # MEASUREMENT METHODS
    # ========================================================

    # Method to calculate the two-point correlator of the current field
    def two_Point_Correlator(self, t, phi = None):
        if not type(phi) == np.ndarray: phi = self.Phi
        Phi_Zero = phi[tuple([0]*4)]
        RET = 0
        for x, _ in np.ndenumerate(phi[0]):
            RET += Phi_Zero * phi[t][x]
        return RET

    # Method to calculate the two-point correlator of the current field, averaged over all time values
    def two_Point_Average(self, t, phi = None):
        if not type(phi) == np.ndarray: phi = self.Phi
        RET = 0
        shift = np.zeros(4)
        shift[0] = t
        for x, _ in np.ndenumerate(phi):
            RET += phi[x] * phi[tuple(((x + shift)%self.Shape).astype(int))]
        return RET / self.Shape[0]

    # Method to calculate the average and error of all possible two point correlators
    def two_Point_Corr_Full(self, Tracker = None, Full = True):
        if Full: t_s = np.linspace(0, self.Size[0]//2, self.Shape[0]//2+1)
        else: t_s = np.linspace(0, 1, 2)
        TPC = np.zeros([t_s.size, len(self.History)])
        if not Tracker == None:
            runs = len(self.History)*len(t_s)
            Tracker.START()
        for i in range(len(self.History)):
            for t in range(len(t_s)):
                if not Tracker == None: Tracker.FLUSH(t+(i*len(t_s)), runs)
                TPC[t, i] = self.two_Point_Average(t, phi = self.History[i])
        if not Tracker == None:
            Tracker.FLUSH_Final(runs, runs)
            print()
        TP = TPC.mean(axis = 1)
        TP = TP / TPC.mean(axis = 1)[0]
        TPE = np.array([Utility.bootstrap(TPC[t,:], 10000) for t in range(len(t_s))])
        TPE = np.sqrt(np.square(TPE[0] * TP / np.square(TPC.mean(axis = 1)[0])) + np.square(TPE / TPC.mean(axis = 1)[0]))
        TPE[0] = 0
        return TP, TPE

    # Method to calculate the expectation value of phi
    def Expectation_Value(self, phi = None):
        if type(phi) == np.ndarray:
            return phi.mean(), None
        else:
            expect = np.array([phi.mean() for phi in self.History])
            error = Utility.bootstrap(expect, 10000)
            return expect.mean(), error  
