import sys
import numpy as np
import matplotlib.pyplot as plt
import time

import Theory as Theory
import Utility

saveformat = '.pdf'

verbose = True

G_s = np.linspace(0,1,11)

Acceptances = []

for G in G_s:
    print()
    Lattice = Theory.Lattice(Parameters = [1,1], Size = [10,10,10,10], Spacing = [1,1,1,1])
    Lattice.History = []
    Lattice.Phi = np.ones(Lattice.Shape)*0.1

    Tracker = Utility.Tracker()

    Sweeps = 50

    Steps = 4
    Sweep_Dmax = np.sqrt(Lattice.Spacing[0]*G)

    Tracker.START()
    for k in range(Sweeps):
        Tracker.FLUSH(k, Sweeps)
        Lattice.Dmax = Sweep_Dmax
        Lattice.Sweep(Steps = Steps, Save = True)
    Tracker.FLUSH_Final(Sweeps, Sweeps)
    print()

    Acceptances.append(Lattice.Accepted/Lattice.Tried)
    print(G,":",Lattice.Accepted/Lattice.Tried)


plt.figure(figsize=(6,4))
plt.plot(G_s, Acceptances,".", label = "Acceptance")
plt.legend(loc = "best")
plt.grid()
plt.xlabel(r"$G$")
plt.ylabel("Acceptance")
plt.savefig("Lat_Acceptance.pdf")
# plt.show()
plt.close()