import sys
import numpy as np
import matplotlib.pyplot as plt
import time

import Theory as Theory
import Utility

Lattice = Theory.Lattice(Parameters = [-1,1], Size = [30,30], Spacing = [1,1])
Lattice.Phi = np.ones(Lattice.Shape)*0

Tracker = Utility.Tracker()

Thermalization = 50
Sweeps = 1

Steps = 4

print("Thermalization:")
Tracker.START()
for k in range(Thermalization):
    Tracker.FLUSH(k, Thermalization)
    Lattice.Sweep(Steps = Steps)
Tracker.FLUSH_Final(Thermalization, Thermalization)
print()

print("Sweeps:")
Tracker.START()
for k in range(Sweeps):
    Tracker.FLUSH(k, Sweeps)
    Lattice.Sweep(Steps = Steps, Save = True)
Tracker.FLUSH_Final(Sweeps, Sweeps)
print()

print("Acceptance:",Lattice.Accepted/Lattice.Tried)

plt.figure(figsize=(9,6))

t = np.linspace(0,Lattice.Shape[0]-1,Lattice.Shape[0])
x = np.linspace(0,Lattice.Shape[1]-1,Lattice.Shape[1])

plt.pcolormesh(t, x, Lattice.Phi, cmap="viridis", rasterized=True)

cbar = plt.colorbar()
cbar.set_label(r"$\Phi$")
plt.xlabel("t")
plt.ylabel("x")
plt.tight_layout()
plt.show()
plt.savefig("Lat_Vis_2d.pdf")
plt.close()