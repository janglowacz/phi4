import sys
import numpy as np
import matplotlib.pyplot as plt
import json

import Utility

class Lattice:
    Accepted = 0
    Tried = 0
    History = []



    # ========================================================
    # CONSTRUCTOR + LOADING & MANIPULATION METHODS
    # ========================================================

    # Constructor of the lattice
    def __init__(self, *args, **kwargs):
        if len(args) == 0 and len(kwargs) == 0:
            print("Lattice initialized without parameters")
        else:
            if "Shape" in kwargs and "Size" in kwargs:
                self.Shape = np.array(kwargs["Shape"])
                self.Size = np.array(kwargs["Size"])
                self.Spacing = np.array(self.Size / self.Shape)
            elif "Shape" in kwargs and "Spacing" in kwargs:
                self.Shape = np.array(kwargs["Shape"])
                self.Spacing = np.array(kwargs["Spacing"])
                self.Size = np.array(self.Size * self.Spacing)
            elif "Spacing" in kwargs and "Size" in kwargs:
                self.Size = np.array(kwargs["Size"])
                self.Spacing = np.array(kwargs["Spacing"])
                self.Shape = np.array(self.Size / self.Spacing).astype(int)
            else: raise Exception("Error in determining lattice dimensions")
            self.Phi = np.zeros(self.Shape)
            self.M_squared, self.Lambda =kwargs["Parameters"]
            self.Dmax = np.sqrt(self.Spacing[0]*0.3)
            print("Lattice initialized with parameters")

    # Method to save the lattice into a file
    def save(self, filename):
        DATA = {"Accepted":     self.Accepted,
                "Tried":        self.Tried,
                "History":      [phi.tolist() for phi in self.History],
                "Shape":        self.Shape.tolist(),
                "Size":         self.Size.tolist(),
                "Spacing":      self.Spacing.tolist(),
                "Phi":          self.Phi.tolist(),
                "M_squared":    self.M_squared,
                "Lambda":       self.Lambda,
                "Dmax":         self.Dmax}
        with open(filename + ".json", mode = "w") as f:
            f.write(json.dumps(DATA))
        print("Lattice saved to file \'"+filename+".json\'")

    # Method to load the lattice from a file
    def load(self, filename):
        with open(filename + ".json", mode = "r") as f:
            DATA = json.loads(f.read())
        self.Accepted   = DATA["Accepted"]
        self.Tried      = DATA["Tried"]
        self.History    = [np.array(phi) for phi in DATA["History"]]
        self.Shape      = np.array(DATA["Shape"])
        self.Size       = np.array(DATA["Size"])
        self.Spacing    = np.array(DATA["Spacing"])
        self.Spacing    = np.array(DATA["Spacing"])
        self.Phi        = np.array(DATA["Phi"])
        self.M_squared  = DATA["M_squared"]
        self.Lambda     = DATA["Lambda"]
        self.Dmax       = DATA["Dmax"]  
        print("Lattice initialized from file \'"+filename+".json\'")



    # ========================================================
    # MONTE CARLO METHODS
    # ========================================================
        
    # Method to perform 1 sweep over the lattice
    def Sweep(self, J=0, Steps=1, Save=False, sampling="uniform"):
        for x, _ in np.ndenumerate(self.Phi): # Sweep over all lattice sites
            for _ in range(Steps): # Steps times

                # Execute the Delta_Phi sampling
                if sampling == "uniform": Delta_Phi = np.random.uniform(-self.Dmax, self.Dmax)
                elif sampling == "gauss": Delta_Phi = np.random.randn() * self.Dmax
                else: raise Exception("\'" + str(sampling) + "\' is not a valid sampling type")

                # Determine the change in the action
                Delta_S = self.Delta_S(x, Delta_Phi, J=J)

                # Perform the Metropolis-Hastings accept-reject step
                if Delta_S < 0 or np.random.uniform(0,1) <= np.exp(-Delta_S):
                    self.Phi[x] += Delta_Phi
                    self.Accepted += 1
                self.Tried += 1
        if Save: self.History.append(self.Phi.copy())

    # Method to calculate the change in action
    def Delta_S(self, x, Delta_Phi, J=0):
        new_Phi = self.Phi[x] + Delta_Phi
        Term_Mu = self.M_squared/2 * (np.square(new_Phi) - np.square(self.Phi[x]))
        Term_Lambda = self.Lambda / 24 * (np.power(new_Phi,4) - np.power(self.Phi[x],4))
        Term_J = J * (Delta_Phi)
        Term_Kin = 0
        for i in range(self.Shape.size):
            shift = np.zeros(self.Shape.size)
            shift[i] = 1
            Term_Kin += (np.square(self.Phi[tuple(((x + shift)%self.Shape).astype(int))] - new_Phi) - np.square(self.Phi[tuple(((x + shift)%self.Shape).astype(int))] - self.Phi[x])) / np.square(self.Spacing[i])
            Term_Kin += (np.square(self.Phi[tuple(((x - shift)%self.Shape).astype(int))] - new_Phi) - np.square(self.Phi[tuple(((x - shift)%self.Shape).astype(int))] - self.Phi[x])) / np.square(self.Spacing[i])
        return (Term_Mu + Term_Lambda + Term_Kin/2 - Term_J) * np.prod(self.Spacing)



    # ========================================================
    # MEASUREMENT METHODS
    # ========================================================

    # Method to calculate the two-point correlator of the current field
    def two_Point_Correlator(self, t, phi = None):
        if not type(phi) == np.ndarray: phi = self.Phi
        Phi_Zero = phi[tuple([0]*self.Shape.size)]
        RET = 0
        for x, _ in np.ndenumerate(phi[0]):
            RET += Phi_Zero * phi[t][x]
        return RET

    # Method to calculate the two-point correlator of the current field, averaged over all time values
    def two_Point_Average(self, t, phi = None):
        if not type(phi) == np.ndarray: phi = self.Phi
        RET = 0
        shift = np.zeros(self.Shape.size)
        shift[0] = t
        for x, _ in np.ndenumerate(phi):
            RET += phi[x] * phi[tuple(((x + shift)%self.Shape).astype(int))]
        return RET / self.Shape[0]

    # Method to calculate the average and error of all possible two point correlators
    def two_Point_Corr_Full(self, Tracker = None, Full = True):
        if Full: t_s = np.linspace(0, self.Size[0]//2, self.Shape[0]//2+1)
        else: t_s = np.linspace(0, 1, 2)
        TPC = np.zeros([t_s.size, len(self.History)])
        if not Tracker == None:
            runs = len(self.History)*len(t_s)
            Tracker.START()
        for i in range(len(self.History)):
            for t in range(len(t_s)):
                if not Tracker == None: Tracker.FLUSH(t+(i*len(t_s)), runs)
                TPC[t, i] = self.two_Point_Average(t, phi = self.History[i])
        if not Tracker == None:
            Tracker.FLUSH_Final(runs, runs)
            print()
        TP = TPC.mean(axis = 1)
        TP = TP / TPC.mean(axis = 1)[0]
        TPE = np.array([Utility.bootstrap(TPC[t,:], 10000) for t in range(len(t_s))])
        TPE = np.sqrt(np.square(TPE[0] * TP / np.square(TPC.mean(axis = 1)[0])) + np.square(TPE / TPC.mean(axis = 1)[0]))
        TPE[0] = 0
        return TP, TPE

    # Method to calculate the expectation value of phi
    def Expectation_Value(self, phi = None):
        if type(phi) == np.ndarray:
            return phi.mean(), None
        else:
            expect = np.array([phi.mean() for phi in self.History])
            error = Utility.bootstrap(expect, 10000)
            return expect.mean(), error